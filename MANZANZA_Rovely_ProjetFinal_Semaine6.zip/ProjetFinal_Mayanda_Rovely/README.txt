========================================================================
PROJET FINAL : PORTFOLIO PERSONNEL - MANZANZA ROVELY
========================================================================

MODE D'EMPLOI :
Ouvrir le sous-dossier "site/" et lancer "index.html" dans un navigateur.

------------------------------------------------------------------------
MINI-RAPPORT DE DÉMARCHE QUALITÉ (OBLIGATOIRE)
------------------------------------------------------------------------

1) ACCESSIBILITÉ (a11y)
- Amélioration 1 : Remplacement complet des conteneurs neutres par du HTML5 sémantique (<header>, <nav>, <main>, <section>, <footer>) pour la lecture d'écran.
- Amélioration 2 : Image du Hero configurée avec alt="" vide car elle est purement décorative, évitant la surcharge cognitive.
- Amélioration 3 : Association explicite de tous les labels de formulaire à leurs champs via les attributs for/id.
- Amélioration 4 : Ajout de la pseudo-classe *:focus-visible en CSS pour garantir un indicateur visuel de focus très contrasté lors de la navigation au clavier.

2) OPTIMISATION PERFORMANCE & ÉCO-CONCEPTION
- Amélioration 5 : Utilisation de l'attribut "defer" sur la balise script pour charger le JS de manière asynchrone sans bloquer l'affichage首屏.
- Amélioration 6 : Choix d'une police système native (--fonts) supprimant l'appel réseau et le téléchargement de fichiers Google Fonts lourds.
- Amélioration 7 : Intégration de l'illustration graphique au format vectoriel .svg ultra-léger au lieu d'un fichier PNG lourd.

3) CORRECTIONS & ROBUSTESSE
- Amélioration 8 : Validation stricte en JS par Expression Régulière (Regex) pour bloquer les formats d'e-mail incorrects et gestion des attributs dynamiques aria-invalid.
- Amélioration 9 : Intégration d'une structure adaptative Mobile-First testée avec succès sur les résolutions cibles 360x640px, 768x1024px et écrans larges sans aucune erreur de débordement.

RÉSULTAT FINAL : 
- 0 erreur détectée dans la Console DevTools (F12).
- Structure propre, légère et instantanée.
========================================================================
