document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('portfolio-contact-form');
    const feedbackZone = document.getElementById('form-feedback');

    // Éléments des champs
    const fields = {
        name: {
            input: document.getElementById('user-name'),
            error: document.getElementById('name-error'),
            message: 'Veuillez renseigner votre nom complet.'
        },
        email: {
            input: document.getElementById('user-email'),
            error: document.getElementById('email-error'),
            regex: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
            message: 'Veuillez saisir une adresse e-mail valide.'
        },
        message: {
            input: document.getElementById('user-message'),
            error: document.getElementById('message-error'),
            message: 'Le corps du message ne peut pas être vide.'
        }
    };

    // Fonction de validation individuelle
    function validateField(field) {
        const value = field.input.value.trim();
        
        // Vérification champ vide
        if (!value) {
            field.error.textContent = field.message;
            field.input.setAttribute('aria-invalid', 'true');
            return false;
        }
        
        // Vérification du format Regex (pour l'e-mail)
        if (field.regex && !field.regex.test(value)) {
            field.error.textContent = field.message;
            field.input.setAttribute('aria-invalid', 'true');
            return false;
        }

        // Si le champ est valide
        field.error.textContent = '';
        field.input.removeAttribute('aria-invalid');
        return true;
    }

    // Écoute de la saisie utilisateur pour effacer l'erreur en temps réel
    Object.values(fields).forEach(field => {
        field.input.addEventListener('input', () => {
            if (field.input.value.trim() !== '') {
                field.error.textContent = '';
                field.input.removeAttribute('aria-invalid');
            }
        });
    });

    // Gestionnaire de soumission de formulaire
    form.addEventListener('submit', (event) => {
        event.preventDefault(); // Bloque le rechargement de la page

        let isFormValid = true;

        // Validation en chaîne de tous les champs
        Object.values(fields).forEach(field => {
            const isValid = validateField(field);
            if (!isValid) {
                isFormValid = false;
            }
        });

        // Affichage du feedback global
        feedbackZone.className = 'form-feedback'; // Réinitialisation des classes
        
        if (isFormValid) {
            feedbackZone.classList.add('success');
            feedbackZone.textContent = 'Merci ! Votre message a été envoyé avec succès.';
            feedbackZone.classList.remove('hidden');
            
            // Réinitialisation du formulaire après envoi réussi
            form.reset();
        } else {
            feedbackZone.classList.add('error');
            feedbackZone.textContent = 'Le formulaire contient des erreurs. Veuillez vérifier les champs obligatoires.';
            feedbackZone.classList.remove('hidden');
        }
    });
});
